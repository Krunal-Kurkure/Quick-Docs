import {createPdf} from 'react-native-pdf-from-image';
import {stripFileUri} from '../utils/fileUtils';
import {savePdfToLibrary} from './pdfLibraryService';

export const generatePdfFromImages = async (imagePaths = [], pdfName = 'PDF') => {
  const cleaned = imagePaths.map(stripFileUri).filter(Boolean);

  if (!cleaned.length) {
    throw new Error('No images selected');
  }

  const temp = await createPdf({
    imagePaths: cleaned,
    name: pdfName,
    paperSize: 'A4',
  });

  const tempPath = temp?.filePath || temp?.path || temp;
  const finalPath = await savePdfToLibrary(tempPath, pdfName);

  return finalPath;
};