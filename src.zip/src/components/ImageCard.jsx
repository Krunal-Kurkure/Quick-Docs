// import React from 'react';
// import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
// import Feather from 'react-native-vector-icons/Feather';
// import ImageNumberInput from './ImageNumberInput';

// const ImageCard = ({item, onCrop, onDelete, onChangeOrder}) => {
//   return (
//     <View style={styles.card}>
//       <Image source={{uri: item.path}} style={styles.preview} resizeMode="cover" />

//       <View style={styles.body}>
//         <Text numberOfLines={1} style={styles.title}>
//           {item.order}. {item.path.split('/').pop()}
//         </Text>

//         <View style={styles.actions}>
//           <ImageNumberInput value={item.order} onChange={val => onChangeOrder(item.id, val)} />

//           <TouchableOpacity style={styles.iconBtn} onPress={() => onCrop(item)}>
//             <Feather name="crop" size={18} color="#0F172A" />
//           </TouchableOpacity>

//           <TouchableOpacity style={styles.iconBtn} onPress={() => onDelete(item.id)}>
//             <Feather name="trash-2" size={18} color="#EF4444" />
//           </TouchableOpacity>
//         </View>
//       </View>
//     </View>
//   );
// };

// export default ImageCard;

// const styles = StyleSheet.create({
//   card: {
//     backgroundColor: '#FFFFFF',
//     borderRadius: 18,
//     overflow: 'hidden',
//     borderWidth: 1,
//     borderColor: '#E2E8F0',
//   },
//   preview: {
//     width: '100%',
//     height: 180,
//     backgroundColor: '#F8FAFC',
//   },
//   body: {
//     padding: 12,
//     gap: 10,
//   },
//   title: {
//     color: '#0F172A',
//     fontWeight: '700',
//   },
//   actions: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     gap: 10,
//   },
//   iconBtn: {
//     width: 42,
//     height: 42,
//     borderRadius: 12,
//     backgroundColor: '#F8FAFC',
//     alignItems: 'center',
//     justifyContent: 'center',
//     borderWidth: 1,
//     borderColor: '#E2E8F0',
//   },
// });

import React from 'react';
import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';

const ImageCard = ({
  item,
  onCrop,
  onDelete,
  isArranging,
  arrangeIndex,
  onToggleArrange,
}) => {
  // If in arrange mode, the whole card is clickable for selection
  const handleCardPress = () => {
    if (isArranging) {
      onToggleArrange(item.id);
    }
  };

  const isSelected = arrangeIndex !== null && arrangeIndex > 0;

  return (
    <TouchableOpacity
      activeOpacity={isArranging ? 0.7 : 1}
      onPress={handleCardPress}
      style={[
        styles.card,
        isArranging && isSelected && styles.cardSelected,
      ]}>
      
      {/* Top Left Number Badge (Only in Arrange Mode) */}
      {isArranging && (
        <View style={[styles.badge, isSelected && styles.badgeActive]}>
          <Text style={styles.badgeText}>
            {isSelected ? arrangeIndex : ''}
          </Text>
        </View>
      )}

      <Image source={{uri: item.path}} style={styles.preview} resizeMode="cover" />

      <View style={styles.body}>
        <Text numberOfLines={1} style={styles.title}>
          {!isArranging && `${item.order}. `}{item.path.split('/').pop()}
        </Text>

        {/* Hide actions while arranging to avoid accidental clicks */}
        {!isArranging && (
          <View style={styles.actions}>
            <TouchableOpacity style={styles.iconBtn} onPress={() => onCrop(item)}>
              <Feather name="crop" size={16} color="#0F172A" />
            </TouchableOpacity>

            <TouchableOpacity style={[styles.iconBtn, styles.deleteBtn]} onPress={() => onDelete(item.id)}>
              <Feather name="trash-2" size={16} color="#EF4444" />
            </TouchableOpacity>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

export default ImageCard;

const styles = StyleSheet.create({
  card: {
    flex: 1, // Allows cards to share row space equally
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#E2E8F0',
    position: 'relative',
  },
  cardSelected: {
    borderColor: '#8A58FF', // Highlight border when selected
  },
  preview: {
    width: '100%',
    height: 140, // Slightly shorter for 2-column view
    backgroundColor: '#F8FAFC',
  },
  body: {
    padding: 10,
    gap: 8,
  },
  title: {
    color: '#0F172A',
    fontWeight: '700',
    fontSize: 13,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  iconBtn: {
    flex: 1,
    height: 36,
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  deleteBtn: {
    backgroundColor: '#FEF2F2',
    borderColor: '#FECACA',
  },
  badge: {
    position: 'absolute',
    top: 8,
    left: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderWidth: 2,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  badgeActive: {
    backgroundColor: '#8A58FF',
    borderColor: '#8A58FF',
  },
  badgeText: {
    color: '#FFF',
    fontWeight: '800',
    fontSize: 14,
  },
});