export const getBaseName = (pathOrName = '') => {
  const clean = String(pathOrName).split('?')[0];
  return clean.split('/').pop() || '';
};

export const getFileNameWithoutExt = (nameOrPath = '') => {
  const base = getBaseName(nameOrPath);
  return base.replace(/\.pdf$/i, '');
};

export const stripFileUri = (uri = '') => {
  if (!uri) return '';
  return uri.startsWith('file://') ? uri.replace('file://', '') : uri;
};

export const toFileUri = (path = '') => {
  if (!path) return '';
  const clean = stripFileUri(path);
  return encodeURI(clean.startsWith('content://') ? clean : `file://${clean}`);
};

export const sanitizeFileName = (name = 'PDF') => {
  return String(name)
    .replace(/\.pdf$/i, '')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim() || 'PDF';
};

export const formatPdfDate = dateInput => {
  const date = dateInput ? new Date(dateInput) : new Date();
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString([], {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const makeId = () =>
  `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;