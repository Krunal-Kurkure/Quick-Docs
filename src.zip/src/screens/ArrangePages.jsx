import React, {useMemo, useState} from 'react';
import {
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Feather from 'react-native-vector-icons/Feather';
import {useNavigation} from '@react-navigation/native';

import {useDraftPdf} from '../context/DraftPdfContext';
import ImageCard from '../components/ImageCard';

const ArrangePages = () => {
  const navigation = useNavigation();
  const {draftImages, setDraftImageOrder} = useDraftPdf();

  const [arrangeSelection, setArrangeSelection] = useState([]);

  // Keep images in their current saved order for initial display
  const orderedImages = useMemo(
    () => [...draftImages].sort((a, b) => a.order - b.order),
    [draftImages],
  );

  const toggleArrangeSelection = id => {
    if (arrangeSelection.includes(id)) {
      setArrangeSelection(prev => prev.filter(selectedId => selectedId !== id)); // Deselect
    } else {
      setArrangeSelection(prev => [...prev, id]); // Add to numbered sequence
    }
  };

  const saveArrangement = () => {
    // 1. Explicitly tapped images go first
    // 2. Untapped images are appended to the back
    const unselected = orderedImages.filter(img => !arrangeSelection.includes(img.id));
    const finalNewOrder = [...arrangeSelection, ...unselected.map(img => img.id)];

    // 3. Update the global context with the new 1, 2, 3 sequence
    finalNewOrder.forEach((id, index) => {
      setDraftImageOrder(id, index + 1);
    });

    // Go back to the Create PDF screen
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor="#8A58FF" />
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
            <Feather name="arrow-left" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerText}>Arrange Pages</Text>
          <View style={{width: 32}} />
        </View>

        <Text style={styles.help}>
          Tap the pages in the order you want them to appear (1, 2, 3...). Unselected pages will be moved to the end.
        </Text>

        <FlatList
          data={orderedImages}
          keyExtractor={item => item.id}
          numColumns={2} // Forces 2-column layout to match your new ImageCard
          columnWrapperStyle={styles.columnWrapper}
          contentContainerStyle={styles.listContent}
          renderItem={({item}) => {
            const arrangeIndex = arrangeSelection.indexOf(item.id) + 1;
            return (
              <ImageCard
                item={item}
                onCrop={() => {}} // Disabled while arranging
                onDelete={() => {}} // Disabled while arranging
                isArranging={true} // Forces the card into tap-to-select mode
                arrangeIndex={arrangeIndex > 0 ? arrangeIndex : null}
                onToggleArrange={toggleArrangeSelection}
              />
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyText}>No pages yet.</Text>
            </View>
          }
        />

        {/* Fixed Footer for Saving */}
        <View style={styles.footer}>
          <TouchableOpacity style={[styles.footerBtn, styles.saveBtn]} onPress={saveArrangement}>
            <Text style={styles.saveText}>Save Arrangement</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default ArrangePages;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#8A58FF',
  },
  container: {
    flex: 1,
    backgroundColor: '#EFEFEF',
  },
  header: {
    backgroundColor: '#8A58FF',
    paddingHorizontal: 15,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  iconBtn: {
    padding: 4,
  },
  headerText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 18,
  },
  help: {
    paddingHorizontal: 15,
    paddingTop: 16,
    paddingBottom: 8,
    color: '#475569',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '500',
  },
  listContent: {
    padding: 15,
    paddingBottom: 120, // Space for the floating footer
    gap: 12,
  },
  columnWrapper: {
    gap: 12, // Spacing between the two columns
  },
  empty: {
    paddingTop: 40,
    alignItems: 'center',
  },
  emptyText: {
    color: '#475569',
  },
  footer: {
    position: 'absolute',
    left: 15,
    right: 15,
    bottom: 18,
    flexDirection: 'row',
  },
  footerBtn: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 15,
    alignItems: 'center',
  },
  saveBtn: {
    backgroundColor: '#8A58FF',
  },
  saveText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
});