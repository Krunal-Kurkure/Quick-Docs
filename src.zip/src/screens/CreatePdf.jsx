import React, { useMemo, useState, useEffect } from 'react';
import {
  Alert,
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Feather from 'react-native-vector-icons/Feather';
import { useNavigation } from '@react-navigation/native';

import {
  captureImageFromCamera,
  pickImagesFromGallery,
} from '../services/imagePickerService';

import { generatePdfFromImages } from '../services/pdfGeneratorService';
import { useDraftPdf } from '../context/DraftPdfContext';
import ImageCard from '../components/ImageCard';
import SavePdfModal from '../components/SavePdfModal';
import { usePdfContext } from '../context/PdfContext';

const LOADING_MESSAGES = [
  'Creating your PDF...',
  'Stitching the pages together...',
  'Large images take time, please be patient...',
  'Your PDF is on the way...',
  'Just a little bit longer...',
  "Almost there, don't be too fast...",
];

const CreatePdf = () => {
  const navigation = useNavigation();
  // Pulled in reorderAllDraftImages instead of setDraftImageOrder
  const {
    draftImages,
    addDraftImages,
    removeDraftImage,
    reorderAllDraftImages,
    clearDraft,
  } = useDraftPdf();
  const { refreshLibrary } = usePdfContext();

  const [saveVisible, setSaveVisible] = useState(false);

  // Arrange States
  const [isArranging, setIsArranging] = useState(false);
  const [arrangeSelection, setArrangeSelection] = useState([]);

  // Loading States
  const [creating, setCreating] = useState(false);
  const [loadingMsgIndex, setLoadingMsgIndex] = useState(0);

  useEffect(() => {
    let interval;
    if (creating) {
      setLoadingMsgIndex(0);
      interval = setInterval(() => {
        setLoadingMsgIndex(prev => (prev + 1) % LOADING_MESSAGES.length);
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [creating]);

  const orderedImages = useMemo(
    () => [...draftImages].sort((a, b) => a.order - b.order),
    [draftImages],
  );

  const addFromGallery = async () => {
    try {
      const images = await pickImagesFromGallery();
      if (images?.length) addDraftImages(images);
    } catch (e) {
      Alert.alert('Gallery', 'Could not pick images.');
    }
  };

  const addFromCamera = async () => {
    try {
      const images = await captureImageFromCamera();
      if (images?.length) addDraftImages(images);
    } catch (e) {
      Alert.alert('Camera', 'Could not capture image.');
    }
  };

  const onCrop = item => {
    navigation.navigate('CropImage', { draftId: item.id });
  };

  // ARRANGEMENT LOGIC
  const startArranging = () => {
    setIsArranging(true);
    setArrangeSelection([]);
  };

  const toggleArrangeSelection = id => {
    if (arrangeSelection.includes(id)) {
      setArrangeSelection(prev => prev.filter(selectedId => selectedId !== id));
    } else {
      setArrangeSelection(prev => [...prev, id]);
    }
  };

  const saveArrangement = () => {
    const unselected = orderedImages.filter(
      img => !arrangeSelection.includes(img.id),
    );
    const finalNewOrder = [
      ...arrangeSelection,
      ...unselected.map(img => img.id),
    ];

    // Send the entire array at once to prevent race conditions
    reorderAllDraftImages(finalNewOrder);

    setIsArranging(false);
    setArrangeSelection([]);
  };

  const cancelArrangement = () => {
    setIsArranging(false);
    setArrangeSelection([]);
  };

  // PDF GENERATION
 // PDF GENERATION
  const createPdf = async pdfName => {
    if (!orderedImages.length) {
      Alert.alert('No images', 'Please add images first.');
      return;
    }

    setSaveVisible(false);
    setCreating(true); 

    setTimeout(async () => {
      try {
        const finalPath = await generatePdfFromImages(
          orderedImages.map(item => item.path),
          pdfName || 'PDF',
        );

        // 1. CRITICAL FIX: Ensure the URI strictly has exactly one 'file://' prefix for Android
        // 1. Ensure file:// prefix
        const properUri = finalPath.startsWith('file://') 
          ? finalPath 
          : `file://${finalPath}`;

        await refreshLibrary();
        clearDraft();
        setCreating(false); 
        
        // 2. CRITICAL FIX: Add ?t=timestamp to force bypass the cache
        navigation.navigate('PdfViewer', {
          pdf: {
            path: finalPath, // Keep raw path for backend/sharing
            uri: `${properUri}?t=${Date.now()}`,  // <--- Added timestamp here!
            displayName: pdfName,
            createdLabel: new Date().toLocaleString(),
          },
        });
        
        Alert.alert('Saved', 'PDF created and saved to your library.');
      } catch (e) {
        console.log(e);
        setCreating(false);
        Alert.alert('Create PDF failed', 'Unable to create PDF. Check image sizes.');
      }
    }, 150); // Slightly increased buffer to 150ms to allow file system sync
  };
  
  return (
    <SafeAreaView style={styles.safeAreaCont} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor="#8A58FF" />

      <Modal visible={creating} transparent={true} animationType="fade">
        <View style={styles.loadingOverlay}>
          <ActivityIndicator
            size="large"
            color="#8A58FF"
            style={styles.spinner}
          />
          <Text style={styles.loadingText}>
            {LOADING_MESSAGES[loadingMsgIndex]}
          </Text>
        </View>
      </Modal>

      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
          >
            <Feather name="arrow-left" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerText}>
            {isArranging ? 'Arrange Pages' : 'Create PDF'}
          </Text>
          <View style={{ width: 32 }} />
        </View>

        {!isArranging && (
          <View style={styles.topActions}>
            <TouchableOpacity style={styles.actionBtn} onPress={addFromGallery}>
              <Feather name="image" size={18} color="#0F172A" />
              <Text style={styles.actionText}>Gallery</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionBtn} onPress={addFromCamera}>
              <Feather name="camera" size={18} color="#0F172A" />
              <Text style={styles.actionText}>Camera</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionBtn}
              onPress={startArranging}
              disabled={orderedImages.length < 2}
            >
              <Feather
                name="layers"
                size={18}
                color={orderedImages.length < 2 ? '#94A3B8' : '#0F172A'}
              />
              <Text
                style={[
                  styles.actionText,
                  orderedImages.length < 2 && { color: '#94A3B8' },
                ]}
              >
                Arrange
              </Text>
            </TouchableOpacity>
          </View>
        )}

        <FlatList
          data={orderedImages}
          keyExtractor={item => item.id}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
          contentContainerStyle={[
            styles.listContent,
            isArranging && { paddingTop: 15 },
          ]}
          renderItem={({ item }) => {
            const arrangeIndex = arrangeSelection.indexOf(item.id) + 1;
            return (
              <ImageCard
                item={item}
                onCrop={onCrop}
                onDelete={removeDraftImage}
                isArranging={isArranging}
                arrangeIndex={arrangeIndex > 0 ? arrangeIndex : null}
                onToggleArrange={toggleArrangeSelection}
              />
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyText}>
                Add images to start creating a PDF.
              </Text>
            </View>
          }
        />

        <View style={styles.footer}>
          {isArranging ? (
            <>
              <TouchableOpacity
                style={[styles.footerBtn, styles.clearBtn]}
                onPress={cancelArrangement}
              >
                <Text style={styles.clearText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.footerBtn, styles.saveBtn]}
                onPress={saveArrangement}
              >
                <Text style={styles.saveText}>Save Arrangement</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity
                style={[styles.footerBtn, styles.clearBtn]}
                onPress={() => clearDraft()}
                disabled={!draftImages.length}
              >
                <Text style={styles.clearText}>Clear</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.footerBtn, styles.saveBtn]}
                onPress={() => setSaveVisible(true)}
                disabled={!draftImages.length}
              >
                <Text style={styles.saveText}>Create PDF</Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        <SavePdfModal
          visible={saveVisible}
          defaultName={`PDF_${new Date().toISOString().slice(0, 10)}`}
          onClose={() => setSaveVisible(false)}
          onSave={createPdf}
        />
      </View>
    </SafeAreaView>
  );
};

export default CreatePdf;

const styles = StyleSheet.create({
  safeAreaCont: {
    flex: 1,
    backgroundColor: '#8A58FF',
  },
  container: {
    flex: 1,
    backgroundColor: '#EFEFEF',
  },
  header: {
    backgroundColor: '#8A58FF',
    paddingHorizontal: 15,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backBtn: {
    padding: 4,
  },
  headerText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 18,
  },
  topActions: {
    flexDirection: 'row',
    gap: 10,
    padding: 15,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  actionText: {
    color: '#0F172A',
    fontWeight: '700',
    fontSize: 12,
  },
  listContent: {
    paddingHorizontal: 15,
    paddingBottom: 120,
    gap: 12,
  },
  columnWrapper: {
    gap: 12,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
  },
  emptyText: {
    color: '#475569',
    fontSize: 14,
    textAlign: 'center',
  },
  footer: {
    position: 'absolute',
    left: 15,
    right: 15,
    bottom: 18,
    flexDirection: 'row',
    gap: 10,
  },
  footerBtn: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 15,
    alignItems: 'center',
  },
  clearBtn: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  saveBtn: {
    backgroundColor: '#8A58FF',
  },
  clearText: {
    color: '#0F172A',
    fontWeight: '700',
    fontSize: 15,
  },
  saveText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
  loadingOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  spinner: {
    marginBottom: 20,
    transform: [{ scale: 1.5 }],
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 26,
  },
});
